#include "Ammo.h"

size_t Ammo::numberStar = 10;