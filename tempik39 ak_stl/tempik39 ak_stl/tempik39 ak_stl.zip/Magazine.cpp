#include "Magazine.h"

