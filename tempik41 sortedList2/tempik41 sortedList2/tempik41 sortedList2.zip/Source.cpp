#include <iostream>
#include <ctime>
#include <Windows.h>
#include <conio.h>
#include "sortedList.h"
#include <string>


using std::cout;
using std::endl;
using std::string;

#define br cout << endl

#define _EXEPT_START try {
#define _EXEPT_END } \
	catch (std::exception &e) { \
	std::cout << "Error: " << e.what(); \
} \
catch (...) { \
	std::cout << "���-�� ����� �� ���... Chrome.(c) "; \
}


struct myPair
{
	int n;
	string s;
	myPair(int n, string s) : n(n), s(s){};
};

bool operator==(const myPair &m1, const myPair &m2)
{
	return m1.n == m2.n;
}

bool operator<(const myPair &m1, const myPair &m2)
{
	return m1.n < m2.n;
}

std::ostream & operator<<(std::ostream &o, const myPair &m)
{
	o << m.s << " = " << m.n << endl;
	return o;
}

template <typename T>
bool operator<=(const T &t1, const T &t2)
{
	return (t1 == t2 || t1 < t2);
}

int main() 
{
	_EXEPT_START

	SetConsoleOutputCP(1251);
	SetConsoleCP(1251);

	sortedList<myPair> mp1;
	
	cout << "Blank sList: "; 
	mp1.show();
	cout << "\n\n";

	mp1.insert(myPair(10, "�� ������"));
	mp1.insert(myPair(20, "�� ��������!"));
	mp1.emplace(15, "� �� �\'���������!");
	//s1.insert(100);

	cout << "s1 after insert:\n";
	mp1.show();
	cout << "\n\n";


	/*
	s1.remove(3);
	cout << "s1 after del 3: ";
	s1.show();
	cout << "\n\n";

	s1.remove(40);
	cout << "s1 after del 40: ";
	s1.show();
	cout << "\n\n";

	sortedList<int> s2(s1);
	cout << "s2(s1): ";	s2.show();
	cout << "s2 size: " << s2.getSize() << endl;
	cout << "\n\n";

	s1.insert(3);
	cout << "s1 after insert 3: ";
	s1.show();

	cout << "s2(s1): "; s2.show();
	cout << "s2 size: " << s2.getSize() << endl;
	cout << "\n\n";

	cout << "before s2 = s1:\n";
	cout << "s2: ";	s2.show();
	cout << "s1: ";	s1.show();

	cout << "after s2 = s1:\n";	s2 = s1;
	cout << "s2: ";	s2.show();
	cout << "s1: ";	s1.show();
	
	cout << "s1 del 100:\n";	s2 = s1;
	s1.remove(100);
	cout << "s2: ";	s2.show();
	cout << "s1: ";	s1.show();
	cout << "\n\n";
	
	cout << "s2 remove at 0:\n";
	s2.removeAt(0);
	cout << "s2: ";	s2.show();
	cout << "s1: ";	s1.show();
	cout << "\n\n";

	cout << "s2 remove at 1:\n";
	s2.removeAt(1);
	cout << "s2: ";	s2.show();
	cout << "s1: ";	s1.show();
	cout << "\n\n";

	//cout << "s2 remove at 1:\n";
	//s2.removeAt(1);
	//cout << "s2: ";	s2.show();
	//cout << "s1: ";	s1.show();
	//cout << "\n\n";

	s2.insert(10);
	cout << "s2: ";	s2.show();
	cout << "s2 first element: " << s2.first() << endl;
	cout << "s2 [0]: " << s2[0] << endl;

	
	cout << "s1: ";	s1.show();
	cout << "s2: ";	s2.show();

	(s2[0] = 999 )= s1[0];
	cout << "s1: ";	s1.show();
	cout << "s2: ";	s2.show();
	*/

	_EXEPT_END
	return 0;
}
