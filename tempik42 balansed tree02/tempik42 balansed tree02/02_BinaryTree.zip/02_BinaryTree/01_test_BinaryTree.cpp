#include <iostream>
using namespace std;

#include "BinaryTreeInt.h"

void main()
{
	BinaryTreeInt bt1;
	bt1.add( 111 , "one hundred eleven" );
	bt1.add( 222 , "two hundreds twenty two" );
	bt1.add( 22 , "twenty two" );
	bt1.add( 11 , "eleven" );
	bt1.add( 33 , "thirty three" );
	bt1.add( 333 , "three hundreds thirty three" );
	bt1.add( 300 , "three hundreds" );
	bt1.add( 3 , "three" );
	bt1.add( 5 , "five" );
	bt1.add( 7 , "seven" );
	bt1.add( 9 , "nine" );

	cout << bt1;

	string * pValue;

	cout <<"FindByKey( 11 ) = ";
	pValue = bt1.FindByKey( 11 );
	if( pValue != nullptr )
	{
		cout <<*pValue <<endl;
	}
	else
	{
		cout <<"Not found !\n";
	}


	cout <<"FindByKey( 12 ) = ";
	pValue = bt1.FindByKey( 12 );
	if( pValue != nullptr )
	{
		cout <<*pValue <<endl;
	}
	else
	{
		cout <<"Not found !\n";
	}

	cout <<"\n\n_____  bt1.RemoveByKey( 11 )  _____\n" ;
	bt1.RemoveByKey( 11 );
	cout << bt1;

	cout <<"\n\n_____  bt1.RemoveByKey( 111 )  _____\n" ;
	bt1.RemoveByKey( 111 );
	cout << bt1;

/*	
	cout <<"\n\n____ clear() _________\n";
	bt1.clear();
	cout <<bt1 <<endl;

*/

	cout <<"\n\n\n";
}



