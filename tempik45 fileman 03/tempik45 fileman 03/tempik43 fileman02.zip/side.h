#pragma once
#include <Windows.h>
#include <io.h>
#include <string>
#include "vec.h"
#include <iomanip>
#include <ctime>
#include <iostream>

using std::string;
using std::cout;
using std::endl;

class side
{
public:
	side(string p, size_t x, size_t y);
	void show() const;
	bool mooveDown();
	bool mooveUp();
	bool inactive();
	bool active();

	static HANDLE hand;

 private:
	bool fillFiles();
	void showTwoLines(size_t row) const;
	
	void makeLine(const _finddata_t &finfo, string &str) const;

	vec<_finddata_t> files;
	size_t indexFile;
	size_t indexRow;
	size_t upIndexFile;
	size_t posX;
	size_t posY;
	string path;
	bool isActive;
	const size_t countFiles;
};

