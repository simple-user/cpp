#include "Nyamka.h"


Nyamka::Nyamka(Pole &p) : pole(p), gamePoints(0)
{	
}

void Nyamka::init()
{
	srand(unsigned(time(0)));

	for (size_t c = countNyam; c; --c)
	{
		size_t x = 0;
		size_t y = 0;
		if (!pole.isFree())
			throw exception(string("Error while constract nyamka. No free places!").c_str());

		do
		{
			x = rand() % pole.width;
			y = rand() % pole.height;
		} while (pole.chekCoord(x, y)); // ��������� ���� ����� ������


		pole.setCoord(x, y, 1);
		vecNyam.emplace_back(x, y, getColorNyam()); // ��-��! :)

	}

	showStartNyamki();
	writePoints(7);
}

void Nyamka::createNewNyam(vector<Nyam>::iterator &itNyam)
{
	if (!pole.isFree())
	{
		vecNyam.erase(itNyam);
		return; //���� ��� ���� ������ ������� �� ���������!
	}
	
	size_t x = 0;
	size_t y = 0;

	do
	{
		x = rand() % pole.width;
		y = rand() % pole.height;
	} while (pole.chekCoord(x, y)); // ��������� ���� ����� ������


	pole.setCoord(x, y, 1);
	 // ��-��! :)
	itNyam->coord.X = x;
	itNyam->coord.Y = y;
	itNyam->color = getColorNyam();

	showOneNyam(*itNyam);
}

void Nyamka::showStartNyamki() const
{
	for (auto a : vecNyam)
	{
		showOneNyam(a);
	}
}

inline void Nyamka::showOneNyam(Nyam n) const
{
	n.coord.X += pole.xMin;
	n.coord.Y += pole.yMin;
	SetConsoleCursorPosition(pole.hand, n.coord);
	SetConsoleTextAttribute(pole.hand, n.color);
	cout << CharNyamka;
}

bool Nyamka::checkNyam(COORD c, WORD & col)
{
	bool res = false;
	for (vector<Nyam>::iterator it = vecNyam.begin(); it!=vecNyam.end(); ++it)
	{
		if (it->coord == c)
		{
			col = it->color;
			switch (it->color)
			{
			case BLUE: ++gamePoints; break;
			case GREEN: gamePoints+=2; break;
			case RED: gamePoints+=3; break;
			case WHITE: gamePoints+=4; break;
			}
			
			
			writePoints(col);

			createNewNyam(it);
			res = true;
			break;
		}
	}
	return res;
}