#include <io.h>


long showFilesByPath(const char * path, long start=0);
