#include "side.h"

HANDLE side::hand = GetStdHandle(STD_OUTPUT_HANDLE);

